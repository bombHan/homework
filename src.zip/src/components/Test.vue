<template>
  <div id="test">
      <p>你好我是test界面!</p>
      <p>store中储存的a数据为：{{$store.state.state.a}}</p>
      <p>a在getters中执行add3函数返回的数据:{{$store.getters.add3}}</p>
      <button @click="$store.dispatch('add2')">加ifTest或者还原</button>
      <router-link  to='/'>回主页</router-link>
      <ul>
          <child v-for="(item,index) in li" v-bind:it="item" v-bind:inde="index"/>
      </ul>
      <p>根据网页路由传的值为：{{$route.params.name}}</p>
     
  </div>
</template>

<script>
export default {
    name:'test',
    data(){
      return{
         li:['信息一','信息二','信息三','信息四','信息五']
      }
    },
    components:{
        'child':{
        props:['it','inde'],
        template:`<li>{{inde}}  {{it}}</li>`
        }
    },
    methods:{
        hi(){
            alert('欢迎来到test页面！')
        }
    },
    mounted(){
       // this.hi()
    }
}
</script>

<style>

</style>
