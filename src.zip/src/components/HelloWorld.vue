<template>
  <div class="hello">
    <p>这是vuex中的数据：{{$store.state.state.a}}</p>
    <button @click="$store.commit('add',2)">为上面数据加两次test</button>
    <router-link :to="{path:'/test/123'}">去test页面</router-link>
    <input type="text" v-model="msg">
   <p> {{msg}} </p>
    <button v-bind:id="'list-' + id" v-on:click="change">点我顺序倒置</button>
  <p v-if="saw">你好我是测试文字</p>
  <button @click="toggel">点我隐藏上述文字</button>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App',
      id : 1,
      saw: true
    }
  },
  methods:{
     change(){
      this.msg = this.msg.split('').reverse().join('');
     },
     toggel(){
        this.saw=!this.saw;
     }

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
