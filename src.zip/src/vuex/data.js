export default({
    state:{
        a:'aaa'
    },
    mutations:{
        add(state,n){
           for(let i=0;i<n;i++){
             state.a+='test'
           }
        }
    },
    actions:{
        add2(state){
            if(state.state.a==='aaa'){
                state.state.a+='ifTest'
            }else{
                state.state.a='aaa';
            }
        }
    },
    getters:{
        add3(state){
            return state.a+'getters';
        }
    }
})