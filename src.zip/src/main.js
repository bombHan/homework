// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import store from './vuex/index'

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  template: '<App/>',
  components: { App }
})

router.beforeEach(function(to,from,next){ //路由为进入其他页面之前执行的函数
    alert('您来到了一个新的界面!地址为：'+to.path);
    next();
})

router.afterEach(function(to,from){ //在进入其他页面之后执行的函数
   //alert('您已经成功进入该页面！')
})
