<template>
  <div id="app">
    <child v-bind:mm='massage'/>
    <p>{{massage}}</p>
    <img src="./assets/logo.png">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'app',
  data(){
    return{
       massage:'你好我是测试文字'
    }
  },
  components:{
    'child':{
      props:['mm'],
      template:`<p>子组件继承父组件内容：{{mm}}</p>`
    }
  }

}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
