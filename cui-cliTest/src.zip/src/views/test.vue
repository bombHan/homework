<template>
    <div>test route</div>
</template>
<script>
	/**
	 * Created by fuzl on 2017-11-9.
	 */
</script>
<style></style>