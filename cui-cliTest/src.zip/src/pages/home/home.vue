<template>
    <div id="test"> 
	<el-button type="primary" round><a href="index.html">回去总页面</a></el-button>    
	<p>你好我是测试文字！</p>
	<p>现在的时间是:{{date}}</p>
	</div>
</template>
<script>
import UrlEnum from "../../constants/url"

export default {
	data(){
		return {
			userList: [],
			date: (new Date()).toLocaleString(),
			timer: -1,
			tableData: []
		}
	},
	props: {},
	methods: {
		updateDate: function(){
			this.date = (new Date()).toLocaleString()
		}
	},
	created(){
		
	},
	mounted(){
		this.timer = setInterval(()=>{
			this.updateDate()
		}, 1000)
	},
	beforeDestroyed(){
		clearInterval(this.timer)
	}
}
</script>
<style>
a{color: white;text-decoration: none}
</style>