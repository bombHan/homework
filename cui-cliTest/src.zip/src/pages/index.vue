<template>
  <div id="index">
    <el-button type="primary" round><a href="home.html">1. 简单页面</a></el-button>
    <el-button type="primary" round><a href="has-route.html">2. 有前端路由的页面</a></el-button>
    <el-button type="primary" round><a href="qwe.html">3.自己写的页面含有登录 注册 付款</a></el-button>

  </div>
</template>
<script>
export default {
   
}
</script>
<style>
    a{
        text-decoration: none;
        color:white;
    }
</style>
