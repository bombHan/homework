/**
 * Created by fuzl on 2017-11-8.
 */
export default {
	GetUserList: "request_getUserList",
	GetOrderList: "request_getOrderList"
}